# exceptions.py
class EmptyStringError(Exception):
    pass
