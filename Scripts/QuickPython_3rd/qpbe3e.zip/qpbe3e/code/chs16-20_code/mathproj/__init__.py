print("Hello from mathproj init")
__all__ = ['comp']
version = 1.03
