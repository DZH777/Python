def h():
    return "Called function h in module n2"
