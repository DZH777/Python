print("Hello from numeric init")
