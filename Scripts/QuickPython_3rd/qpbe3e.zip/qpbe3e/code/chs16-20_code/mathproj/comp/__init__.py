__all__ = ['c1']
print("Hello from mathproj.comp init")
