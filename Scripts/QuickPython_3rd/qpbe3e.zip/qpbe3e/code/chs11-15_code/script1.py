def main():                               #A
    print("this is our first test script file")
main()                                    
