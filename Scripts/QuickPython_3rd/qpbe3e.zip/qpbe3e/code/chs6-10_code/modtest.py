"""modtest: our test module"""
def f(x):
    return x
def _g(x):
    return x
a = 4
_b = 2
